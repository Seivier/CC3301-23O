#ifndef _MODIFICAR_H_
#define _MODIFICAR_H_

void modificar(char* nom_dic, char* palabra, char* def, int n_lin, int ancho);

#endif //_MODIFICAR_H_
